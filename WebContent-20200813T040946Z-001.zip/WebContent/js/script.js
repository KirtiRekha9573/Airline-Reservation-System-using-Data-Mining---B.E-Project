$(function(){ 							   

	// radiys box
	$('.header').css({"border-radius": "2px 2px 0px 0px", "-moz-border-radius":"2px 2px 0px 0px", "-webkit-border-radius":"2px 2px 0px 0px"});
	$('.hbg').css({"border-radius": "0 20px 20px 0", "-moz-border-radius":"0 20px 20px 0", "-webkit-border-radius":"0 20px 20px 0"});
	$('.pagenavi a, .pagenavi .current').css({"border-radius": "5px", "-moz-border-radius":"5px", "-webkit-border-radius":"5px"});
	$('.mainbar .spec a.rm').css({"border-radius": "10px", "-moz-border-radius":"10px", "-webkit-border-radius":"10px"});
	$('.fbg').css({"border-radius": "20px 0 0 0", "-moz-border-radius":"20px 0 0 0", "-webkit-border-radius":"20px 0 0 0"});
	$('.content').css({"border-radius": "0 0px 0 0px", "-moz-border-radius":"0 0px 0 0px", "-webkit-border-radius":"0 0px 0 0px"});
	
});	