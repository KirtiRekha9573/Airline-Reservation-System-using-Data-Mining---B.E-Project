package com.airlines;

import java.sql.Connection;
import java.sql.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
public class A {
	public static void main(String[] args) throws SQLException {
		Connection con = ConnectionProvider.getConn();
		PreparedStatement ps1 = con.prepareStatement("select * from dataset");
		ResultSet rs=ps1.executeQuery();
		String age;
		int age1;
		String place;
		while(rs.next())
		{
			place=rs.getString("destination");
			age=rs.getString("dob");
			String [] arr=age.split("-");
			if(arr.length==3)
			{
			age1=2017-Integer.parseInt(arr[2]);
			if(age1>=0 && age1<=19)
			{
				Statement st=con.createStatement();
				st.executeUpdate("INSERT INTO `temp`( `teenage`, `younge`, `middle`, `old`) VALUES "
							+ "('"+place+"',NULL,NULL,NULL)");
			}
			
			else if(age1<=40 && age1>=20)
			{
				Statement st=con.createStatement();
				st.executeUpdate("INSERT INTO `temp`( `teenage`, `younge`, `middle`, `old`) VALUES "
							+ "(NULL,'"+place+"',NULL,NULL)");
			}
			else if(age1<=60 && age1>=41)
			{
				Statement st=con.createStatement();
				st.executeUpdate("INSERT INTO `temp`( `teenage`, `younge`, `middle`, `old`) VALUES "
							+ "(NULL,NULL,'"+place+"',NULL)");
			}
			else if(age1<=100 && age1>=61)
			{
				Statement st=con.createStatement();
				st.executeUpdate("INSERT INTO `temp`( `teenage`, `younge`, `middle`, `old`) VALUES "
							+ "(NULL,NULL,NULL,'"+place+"')");
			}
		}
			
		}
		//ps1.setString(1,"westcluster");
		//int i = ps1.executeUpdate();
		/*ps1.setString(1,"eastcluster");
		ps1.executeUpdate();
		ps1.setString(1,"westcluster");
		ps1.executeUpdate();
		ps1.setString(1,"northcluster");
		ps1.executeUpdate();
		ps1.setString(1,"southcluster");
		ps1.executeUpdate();*/
		/*String s="February-5-1991";
		String [] arr=s.split("-");
		//System.out.println(2017-Integer.parseInt(arr[2]));
		TreeMap<String,String> tm=new TreeMap<String, String>();
		System.out.println(tm.put("a","a"));
		System.out.println(tm.put("a","a"));
		System.out.println(tm.put("b","a"));*/
		
		
	}

}
