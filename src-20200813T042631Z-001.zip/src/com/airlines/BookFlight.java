package com.airlines;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;
/**
 * Servlet implementation class BookFlight
 */
@WebServlet("/BookFlight")
public class BookFlight extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookFlight() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection cn=ConnectionProvider.getConn();
		HttpSession session=request.getSession();
		String splace=request.getParameter("splace");
		String dest=request.getParameter("dest");
		String jdate=request.getParameter("jdate");
		String email=(String)session.getAttribute("email");
		String[] east = {"mumbai","goa","nagpur","Ahmedabad","leh","pune","Chandigarh","kolhapur","surat"};
		String west[] = {"Cochin","kochi","kolkata","aizawl","madurai","vadodara","shillong"};
		String north[] = {"delhi","srinagar","jammu","shimla","jaipur","jodhpur","dehradun","amritsar","bhopal","lucknow","agra"};
		String south[] = {"tiruvanthapuram","gangtok","diu","banglore","manglore","darjiling","hyderabad","itanagar","chennai","imphal","tirupati"};
		String udest="";
		int flag=0;
		for(int j=0;j<east.length;j++)
		{
			
			if(dest.equalsIgnoreCase(east[j]))
			{
				udest="eastcluster";
				flag=1;
				break;
			}
			
		}
		if(flag==0)
		{
		for(int j=0;j<west.length;j++)
		{
			if(dest.equalsIgnoreCase(west[j]))
			{
				udest="westtcluster";
				flag=1;
				break;
			}
			
		}
		}
		if(flag==0)
		{
		for(int j=0;j<north.length;j++)
		{
			if(dest.equalsIgnoreCase(north[j]))
			{
				udest="northcluster";
				flag=1;
				break;
			}
			
		}
		}
		if(flag==0)
		{
		for(int j=0;j<south.length;j++)
		{
			if(dest.equalsIgnoreCase(south[j]))
			{
				udest="southcluster";
				flag=1;
				break;
			}
			
		}
		}
		
		
		// Cluster string
		
		
		
		
		
		
		//INSERT INTO `diseasedataset`(`id`, `temperature`, `pulserate`, `Betablockers`, `medicalattn`, `possibledisorder`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5],[value-6])
		PreparedStatement ps;
		try {
			ps = cn
					.prepareStatement("insert into bookflight (email,splace,dest, jdate, region) values(?,?,?,?,?)");
			ps.setString(1,email);
			ps.setString(2, splace);
			ps.setString(3, dest);
			ps.setString(4, jdate);
			ps.setString(5, udest);
			
			int r = ps.executeUpdate();
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		RequestDispatcher rd=request.getRequestDispatcher("bookflight.jsp?yes=yes");
		rd.forward(request,response);

		

	}

}
