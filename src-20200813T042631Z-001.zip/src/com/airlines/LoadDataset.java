package com.airlines;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import k_means.DataPoint;
import k_means.JCA;

//import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

/**
 * Servlet implementation class LoadPima
 */

@WebServlet("/LoadDataset")
public class LoadDataset extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		System.out.println("in Loaddataset");
		HttpSession session = request.getSession();
		String filename=(String)session.getAttribute("fname");
		String inputFile = "D:\\work2\\AirLines_newFinal\\WebContent\\dataset\\"+filename;
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		String id;
		
		//INSERT INTO `diseasedataset`(`id`, `temperature`, `pulserate`, `Betablockers`, `medicalattn`, `possibledisorder`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5],[value-6])
		
		String fname; //customername
		String mname;
		String lname;
		String gender; //serviceaptstayed
		String email;
		String mobile;
		String address;
		String dob;
		String source="";
		String destination;
		String journeydate;
		
		
		
		
		//-----------------------------------------------------------
		String[] east = {"mumbai","goa","nagpur","Ahmedabad","leh","pune","Chandigarh","kolhapur","surat"};
		String west[] = {"Cochin","kochi","kolkata","aizawl","madurai","vadodara","shillong"};
		String north[] = {"delhi","srinagar","jammu","shimla","jaipur","jodhpur","dehradun","amritsar","bhopal","lucknow","agra"};
		String south[] = {"tiruvanthapuram","gangtok","diu","banglore","manglore","darjiling","hyderabad","itanagar","chennai","imphal","tirupati"};
		
		//-----------------------------------------------------------
		System.out.println(east.length+" "+west.length);

		
		int total = 0;
		try {

			Connection con = ConnectionProvider.getConn();
			PreparedStatement ps1 = con.prepareStatement("DELETE FROM dataset");
			ps1.executeUpdate();
			PreparedStatement pd1 = con.prepareStatement("DELETE FROM eastcluster");
			pd1.executeUpdate();
			PreparedStatement pd2 = con.prepareStatement("DELETE FROM northcluster");
			pd2.executeUpdate();
			PreparedStatement pd3 = con.prepareStatement("DELETE FROM westtcluster");
			pd3.executeUpdate();
			PreparedStatement pd4 = con.prepareStatement("DELETE FROM southcluster");
			pd4.executeUpdate();
			
			
		

			br = new BufferedReader(new FileReader(inputFile));
			while ((line = br.readLine()) != null) {
				System.out.println(line);
				total++; // use comma as separator
				String[] data = line.split(cvsSplitBy);
				if(data.length==12)
				{
				lname = data[1];
				mname = data[2];
				lname = data[3];
				gender = data[4];
				email = data[5];
				mobile = data[6];
				address = data[7];
				dob = data[8];
				source = data[9];
				destination = data[10];
				journeydate = data[11];
				
				
				Vector dataPoints = new Vector();
				MyStringRandomGen random = new MyStringRandomGen();
				String x1=random.randomNumber();
				double x = Double.parseDouble(x1);
				String y1 = random.randomNumber();
				double y=Double.parseDouble(y1);
		 		String searchquery = "pramod";
				dataPoints.add(new DataPoint(x,y,source));
		         JCA jca = new JCA(2,1000,dataPoints);
		         jca.startAnalysis();
		         
		         Vector[] v = jca.getClusterOutput();
		         for (int i=0; i<v.length; i++){
		             Vector tempV = v[i];
		             System.out.println("-----------Cluster----------");
		             Iterator iter = tempV.iterator();
		             while(iter.hasNext()){
		                 DataPoint dpTemp = (DataPoint)iter.next();
		                 System.out.println(dpTemp.getObjName()+"["+dpTemp.getX()+","+dpTemp.getY()+"]");
		             }
		         }
				
				String udest="dataset";
				int flag=0;
				for(int j=0;j<east.length;j++)
				{
					System.out.println("---------------------------------");
					System.out.println(destination);
					System.out.println(east[j]);
					System.out.println("---------------------------------");
					if(destination.equalsIgnoreCase(east[j]))
					{
						udest="eastcluster";
						flag=1;
						break;
					}
					
				}
				if(flag==0)
				{
				for(int j=0;j<west.length;j++)
				{
					if(destination.equalsIgnoreCase(west[j]))
					{
						udest="westtcluster";
						flag=1;
						break;
					}
					
				}
				}
				if(flag==0)
				{
				for(int j=0;j<north.length;j++)
				{
					if(destination.equalsIgnoreCase(north[j]))
					{
						udest="northcluster";
						flag=1;
						break;
					}
					
				}
				}
				if(flag==0)
				{
				for(int j=0;j<south.length;j++)
				{
					if(destination.equalsIgnoreCase(south[j]))
					{
						udest="southcluster";
						flag=1;
						break;
					}
					
				}
				}
				
				
				// Cluster string
				
				
				
				
				
				
				//INSERT INTO `diseasedataset`(`id`, `temperature`, `pulserate`, `Betablockers`, `medicalattn`, `possibledisorder`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5],[value-6])
				PreparedStatement ps = con
						.prepareStatement("insert into dataset (fname, mname, lname, gender, email, mobile, address, dob, source, destination, journeydate) values(?,?,?,?,?,?,?,?,?,?,?)");

				ps.setString(1, data[1]);
				ps.setString(2, data[2]);
				ps.setString(3, data[3]);
				ps.setString(4, data[4]);
				ps.setString(5, data[5]);
				ps.setString(6, data[6]);
				ps.setString(7, data[7]);
				ps.setString(8, data[8]);
				ps.setString(9, data[9]);
				ps.setString(10, data[10]);
				ps.setString(11, data[11]);
				int r = ps.executeUpdate();
				//------------------------------------------------
				try{
				PreparedStatement ps2 = con
						.prepareStatement("insert into "+udest+" (fname, mname, lname, gender, email, mobile, address, dob, source, destination, journeydate) values(?,?,?,?,?,?,?,?,?,?,?)");
				//ps2.setString(1,udest);
				ps2.setString(1, data[1]);
				ps2.setString(2, data[2]);
				ps2.setString(3, data[3]);
				ps2.setString(4, data[4]);
				ps2.setString(5, data[5]);
				ps2.setString(6, data[6]);
				ps2.setString(7, data[7]);
				ps2.setString(8, data[8]);
				ps2.setString(9, data[9]);
				ps2.setString(10, data[10]);
				ps2.setString(11, data[11]);
				System.out.println("impppppppppp="+udest);
				
				int r2 = ps2.executeUpdate();
				}catch(Exception e)
				{
					System.out.println(e);
				}
			}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("total record : " + total);
		

		response.sendRedirect("adminhome.jsp?yes='yes'");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
