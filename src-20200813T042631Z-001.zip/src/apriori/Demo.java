package apriori;
/*
Author: PRAMOD PAWAR
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

//import org.eclipse.jdt.internal.compiler.ast.ThisReference;

public class Demo {

    public static void main(String[] args) {
      //  demo();
    }

    static String cluster;
    static String month;
    public static void demo(String amountin,String fieldin) {
        AprioriFrequentItemsetGenerator<String> generator =
                new AprioriFrequentItemsetGenerator<>();
                cluster =amountin;
                month = fieldin;
          
                
        List<Set<String>> itemsetList = new ArrayList<>();

        itemsetList.add(new HashSet<>(Arrays.asList(cluster, month)));
        itemsetList.add(new HashSet<>(Arrays.asList(cluster, cluster, month)));
        itemsetList.add(new HashSet<>(Arrays.asList(cluster, cluster, month)));
        itemsetList.add(new HashSet<>(Arrays.asList(cluster, month, cluster, month)));
       

        long startTime = System.nanoTime();
        FrequentItemsetData<String> data = generator.generate(itemsetList, 0.25);
        long endTime = System.nanoTime();

        int i = 1;
        int c = 7;
        System.out.println("--- Frequent itemsets ---");

        for (Set<String> itemset : data.getFrequentItemsetList()) {
            System.out.printf("%2d: %9s, support: %1.1f\n",
                              i++, 
                              itemset,
                              data.getSupport(itemset));
        }
        int t = (int) (((endTime - startTime)) / 1_000_000);
        
        
       /* System.out.printf("Mined frequent itemset in %d milliseconds.\n", 
                          t);*/

        startTime = System.nanoTime();
        List<AssociationRule<String>> associationRuleList = 
                new AssociationRuleGenerator<String>()
                        .mineAssociationRules(data, 0.4);
        endTime = System.nanoTime();

        i = 1;

        System.out.println();
        System.out.println("--- Association rules ---");

        for (AssociationRule<String> rule : associationRuleList) {
            System.out.printf("%2d: %s\n", i++, rule);
        }

        /*System.out.printf("Mined association rules in %d milliseconds.\n",
                          (endTime - startTime) / 1_000_000);*/
    }
}
